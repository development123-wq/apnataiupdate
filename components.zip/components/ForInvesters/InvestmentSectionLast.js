import React from 'react';
import '../../public/css/AboutSection.css'; 
import aboutimg from '../../public/images/about/ab6.png';
import Image from 'next/image';

const ApNatai = () => {
  return (
    <section className="custom-aprole-section">
      {/* Background Layer #f4f4f4 */}
      <div className="custom-aprole-bg"></div>

      <div className="custom-aprole-container">
         {/* Left Side: Image with Large Rounded Corners */}
        <div className="custom-aprole-image-side">
          <div className="custom-aprole-card">
            <Image 
              src={aboutimg} 
              alt="Natai Development" 
              width={650} 
              height={450} 
              className="custom-aprole-img" 
            />
          </div>
        </div>
      

        {/* Right Side: Content */}
        <div className="custom-aprole-content-side">
          <div className="custom-aprole-badge">
            <span className="custom-aprole-square"></span>
            <span className="custom-aprole-badge-text">Oceanfront Living</span>
          </div>

          <h2 className="custom-aprole-title">
            Curated luxury homes in  <br />
            prime locations
          </h2>

          <p className="custom-aprole-desc">
            AP Natai is your gateway to exceptional beachfront living and premier real estate opportunities on Natai Beach, Phang-nga — just north of Phuket, Thailand. With over 20 years of experience in the region’s luxury property market, we specialize in exclusive villas, investment properties, sales, rentals, and full-service property management tailored to discerning buyers and owners alike.
          </p>
          
         <a href="#" class="investors-ddmore">Discover More</a>
        </div>
 
      </div>
    </section>
  );
};

export default ApNatai;