import React from 'react';
import "../../public/css/InvestmentSection.css";


const InvestmentFinal = () => {
  return (
    <div className="final-container">
      {/* Left Column: 50% Width */}
      <div className="final-content">
        <div className="text-wrapper">
          <h2 className="final-title">
            Where coastal beauty meets <br />
            <span className="cyan-highlight">investment</span> excellence
          </h2>
          
          <p className="final-description">
            Venture into a realm where your garden is not just a patch of green but a carefully curated landscape that mirrors the lushness of natai itself. Our landscaping services, infused with knowledgeable advice on local plants and tailored care strategies, transform your outdoor spaces into personal retreats. From choosing the right flora that thrives in the local climate to ensuring they are cared for meticulously, your garden becomes a lush, serene escape right outside your doorstep.
          </p>

          <button className="final-btn">Let's talk</button>
        </div>
      </div>

      {/* Right Column: 50% Width */}
      <div className="final-image-container">
        <img 
          src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80" 
          alt="Coastal Villa Landscape" 
          className="final-img"
        />
      </div>
    </div>
  );
};

export default InvestmentFinal;