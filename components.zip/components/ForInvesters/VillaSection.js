import React from 'react';
import "../../public/css/VillaComponent.css";


const VillaComponent = () => {
  return (
    <div className="hero-container">
      {/* Left Section: Image */}
      <div className="image-section">
        <img 
          src="https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=1200&q=80" 
          alt="Premium Villa" 
        />
      </div>

      {/* Right Section: Content */}
      <div className="content-section">
        <h1 className="main-title">
          <span className="highlight-text">Premium villas</span> with unmatched oceanfront views
        </h1>
        
        <p className="description">
          Every building, from houses and villas to shops and unique floating structures, is 
          not merely constructed but meticulously crafted by ap-natai. Our professional 
          and reliable building contractors, selected through a stringent process, are 
          dedicated to bringing your envisioned project to life. Whether it's an opulent villa 
          overlooking the tranquil seas or a bespoke shop that mirrors the vibrant local 
          culture, we mould every brick and beam with precision, ensuring it's not just a 
          structure but a testament to superior construction and your unique taste.
        </p>

        <button className="read-more-btn">Read more</button>
      </div>
    </div>
  );
};

export default VillaComponent;