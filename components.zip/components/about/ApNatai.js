import React from 'react';
import '../../public/css/AboutSection.css'; 
import aboutimg from '../../public/images/about/ab5.webp';
import Image from 'next/image';

const ApNatai = () => {
  return (
    <section className="custom-aprole-section">
      {/* Background Layer #f4f4f4 */}
      <div className="custom-aprole-bg"></div>

      <div className="custom-aprole-container">
        
      

        {/* Right Side: Content */}
        <div className="custom-aprole-content-side">
          <div className="custom-aprole-badge">
            <span className="custom-aprole-square"></span>
            <span className="custom-aprole-badge-text">Curated Luxury Homes</span>
          </div>

          <h2 className="custom-aprole-title">
            AP Natai’s role in <br />
            Natai’s development
          </h2>

          <p className="custom-aprole-desc">
            As pioneers in Natai’s property landscape, we take pride in our strategic role in shaping its development. Our approach is grounded in sustainability, ensuring that as Natai grows, it does so with respect for the natural environment and local heritage.
          </p>
          
          <p className="custom-aprole-desc">
            Through responsible stewardship, we aim to foster a property market that is vibrant, ethical, and forward-thinking.
          </p>
        </div>
  {/* Left Side: Image with Large Rounded Corners */}
        <div className="custom-aprole-image-side">
          <div className="custom-aprole-card">
            <Image 
              src={aboutimg} 
              alt="Natai Development" 
              width={650} 
              height={450} 
              className="custom-aprole-img" 
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default ApNatai;