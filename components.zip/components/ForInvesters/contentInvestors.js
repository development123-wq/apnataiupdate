import React from 'react';
import "../../public/css/contentinvestors.css";

const TestimonialSection = () => {
  return (
    <section className="content-investors-section">
      <div className="content-investors-content">
        <h2 className="content-investors-heading">
          A decade of unrivaled project management excellence
        </h2>
        <p className="content-investors-paragraph">
          Boasting over a decade of project management experience, spanning international marinas, individual homes, luxurious villas, apartments, and condominiums, ap-natai has burgeoned into the most reliable neighbouring partner for project management in natai and its vicinity. Offering comprehensive solutions in construction and environmental awareness, ap-natai customises its services to suit the owners’ preferences, developing their assets to their utmost potential and interest. The optimal result and luxury of the villas are our paramount priority, ensuring each project not only reflects but also elevates our name and reputation. Whether a project is in its embryonic stages or development has already been set into motion, ap-natai possesses the resources, expertise, and unwavering commitment to steer every project to its successful completion. Through daily, weekly, and monthly planning activities, we ensure that each project is executed with a high standard of professionalism, integrity, and privacy. Recognising the critical role of supervision in achieving efficient and commendable results, we have established a proficient management team to guarantee quality performance. 
        </p>
        <p className="content-investors-paragraph">
          With a wealth of experience in project management and financial cost control of development projects, ap-natai is wholly dedicated to ensuring our customers’ assets are managed with trustworthy and responsible professional services. We uphold only the highest standards of professional service, and achieving customer satisfaction remains the propelling force behind all our operations. With ap-natai at the helm, your project will be navigated to its optimal potential, ensuring your investment realises its true value.
        </p>
      </div>
    </section>
  );
};

export default TestimonialSection;