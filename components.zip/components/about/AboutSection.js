"use client";
import React, { useEffect, useState } from 'react';
import '../../public/css/AboutSection.css'; 
import aboutimg from '../../public/images/about/ab3.webp';
import Image from 'next/image';

const AboutSection = () => {
  const [about, setAbout] = useState(null);

  const stripHtml = (html) => {
    if (!html) return "";
    return html.replace(/<[^>]+>/g, "");
  };

  useEffect(() => {
    fetch("https://techzenondev.com/apnatai/api/about-us")
      .then((res) => res.json())
      .then((data) => setAbout(data.data))
      .catch((err) => console.error("Error fetching about data:", err));
  }, []);

  if (!about) return <div className="custom-loader">Loading...</div>;

  return (
    <section className="custom-about-section">
      {/* Decorative Cyan Bar (Left) */}
      <div className="custom-deco-left-bar"></div>

      <div className="custom-about-container">
        
        {/* Text Content */}
        <div className="custom-about-content">
          <span className="custom-about-subtitle">About us</span>
          <h2 className="custom-about-title">
            Where the beach meets <br />
            <span className="custom-about-highlight">timeless luxury</span>
          </h2>
          <p className="custom-about-desc">
            {about.description ? stripHtml(about.description) : "Lorem Ipsum is simply dummy text of the printing and typesetting industry..."}
          </p>
          
          <ul className="custom-about-list">
            <li><span className="custom-check">✓</span> Distinguished beachfront living for discerning buyers</li>
            <li><span className="custom-check">✓</span> Premium villas with exceptional investment value</li>
          </ul>
        </div>

        {/* Image Side with Decorative Elements */}
        <div className="custom-about-image-wrapper">
          {/* Top Line & Dotted Pattern */}
          <div className="custom-deco-top-line"></div>
          <div className="custom-deco-dots"></div>
          
          <div className="custom-image-card">
            <Image 
              src={aboutimg} 
              alt="Luxury Villa" 
              width={600} 
              height={400} 
              className="custom-img"
            />
          </div>

          {/* Bottom Cyan Shapes */}
          <div className="custom-deco-bottom-right"></div>
          <div className="custom-deco-bottom-box"></div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;